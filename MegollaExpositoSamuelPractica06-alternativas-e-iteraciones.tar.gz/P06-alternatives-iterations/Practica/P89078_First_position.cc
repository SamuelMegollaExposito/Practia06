/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Samuel Megolla Expósito
 * @date 10 noviembre 2022
 * @brief First position
 * Write a program that reads a sequence of natural numbers and prints the position of the first even number.
 *Input
 *Input consists of a sequence of natural numbers that contains, at least, one even number.
 *Output
 *Print the position of the first even number of the sequence.
 */

#include<iostream>

using namespace std;

int main(){

	 int secuencia;
	 int contador=1;
	 cin>>secuencia;
	if(secuencia%2==0){
	cout<<contador<<endl;
	}
   while (secuencia%2!==0) {
    	cin >> secuencia;
    	contador=contador + 1;	
	if(secuencia%2==0){
	cout<<contador<<endl;
	}
   }







return 0;
}
