/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Samuel Megolla Expósito
 * @date 10 noviembre 2022
 * @brief Top to bottom
 *Write a program that reads two numbers x and y, and prints all numbers between x and y (or between y and x), in decreasing order.
*Input
*
*Input consists of two integer numbers x and y.
*
*Output
*Print all integer numbers between x and y (or between y and x), in decreasing order.
 */

#include<iostream>

using namespace std;

int main(){

	int number1{0},number2{0};
	cin>>number1>>number2;

	if(number1>number2){
	
		for(int i = number1; i>=number2; i--){
			cout<<i<<endl;
		}
	}else{
		for(int i = number2; i>=number1; i--){
			cout<<i<<endl;
		}
	
	
	}

return 0;
}
