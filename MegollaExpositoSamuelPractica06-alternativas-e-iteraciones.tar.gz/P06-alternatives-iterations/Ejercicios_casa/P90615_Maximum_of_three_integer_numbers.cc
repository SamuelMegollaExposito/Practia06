#include<iostream>

using namespace std;

int main(){

	int number1{0},number2{0},number3{0};
	cin>>number1>>number2>>number3;

	if(number1>number2){
		if(number1>number3){
			cout<<number1<<endl;
		}else{
			cout<<number3<<endl;
		}
	}else{
		if(number2>number3){
			cout<<number2<<endl;
		}else{
			cout<<number3<<endl;
		}
	}





return 0;
}
