#include<iostream>

using namespace std;

int main(){


	char character{};
	cin>>character;

	static_cast<int>(character);

	if(character>90){
		character=character-32;
		static_cast<char>(character);
	}else{
		character=character+32;
		static_cast<char>(character);
	}
	cout<<character<<endl;

















return 0;
}
