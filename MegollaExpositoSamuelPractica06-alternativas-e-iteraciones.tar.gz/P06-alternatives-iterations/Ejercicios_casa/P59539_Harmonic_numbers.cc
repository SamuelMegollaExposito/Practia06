#include<iostream>
#include<iomanip>

using namespace std;

int main(){

	int number{0};
	double suma{0.0},result{0};

	cin>>number;
	
	for(double i=1;i<=number;i++){
		
		result=result+1/i;
		
	}
cout<<fixed<<setprecision(4)<<result<<endl;








return 0;
}
