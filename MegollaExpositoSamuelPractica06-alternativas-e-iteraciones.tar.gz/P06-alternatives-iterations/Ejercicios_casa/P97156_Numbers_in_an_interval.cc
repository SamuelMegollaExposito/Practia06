#include<iostream>

using namespace std;

int main(){


	int interval1{0}, interval2{0};
	cin>>interval1>>interval2;

	for(int i=interval1;i<=interval2;i++){
		cout<<i<<endl;
	

	}	













return 0;
}
