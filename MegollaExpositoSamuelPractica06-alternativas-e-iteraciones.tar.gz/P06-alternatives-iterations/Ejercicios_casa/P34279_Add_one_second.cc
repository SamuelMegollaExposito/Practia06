#include<iostream>

using namespace std;

int main(){

	int hour{0},minut{0},secon{0};
	
	secon++

	if(secon>59){
		secon=0;
		minut++;
	}
	if(minut>59){
		minut=0;
		hour++;
	}
	if(hour>=24){
		hour=0;
	}
	if(hour<10){
		cout<<"0";
	}
	cout<<hour<<":";
	if(minut<10){
		cout<<"0";
	}
	cout<<minut<<":";
	if(secon<10){
		cout<<"0";
	}
	cout<<secon<<endl;


return 0;
}

		
	


















return 0;
}
